
//NAME : Pinki Kumari
//ROLL.NO : AA.SC.U3BCA2207092

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Cookie;

@WebServlet("/WelcomeServlet")
public class WelcomeServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        if ("admin123".equals(password)) {
            Cookie userCookie = new Cookie("username", username);
            userCookie.setMaxAge(60 * 60); // 1 hour
            response.addCookie(userCookie); // Store the cookie
            
            out.println("<h2>Welcome, " + username + "!</h2>");
            out.println("<form action='HelloServlet' method='post'>");
            out.println("<input type='submit' value='Proceed'>");
            out.println("</form>");
        } else {
            out.println("<h2>Invalid Username or Password. Try Again.</h2>");
            request.getRequestDispatcher("login.html").include(request, response);
        }
    }
}
