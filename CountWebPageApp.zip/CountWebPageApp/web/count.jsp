<%-- 
    Document   : count
    Created on : 11 Feb, 2025, 9:43:14 PM
    Author     : hp
--%>

<!--
NAME : Pinki Kumari
ROLL.NO : AA.SC.U3BCA2207092
-->

<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <title>Page Hit Counter</title>
</head>
<body>

    <h2>Welcome to the Web Page!</h2>

    <%-- 1. Initialize hit counter if it's not already set --%>
    <%
        Integer hitCount = (Integer) application.getAttribute("hitCounter");
        
        if (hitCount == null) {
            hitCount = 1; // First visit
        } else {
            hitCount++; // Increment count on each visit
        }

        // Store updated counter back in application scope
        application.setAttribute("hitCounter", hitCount);
    %>

    <%-- 2. Display the number of hits --%>
    <p><strong>Number of visits:</strong> <%= hitCount %></p>

</body>
</html>

