<%-- 
    Document   : JSP
    Created on : 11 Feb, 2025, 9:01:24 PM
    Author     : hp
--%>

<!--
NAME : Pinki Kumari
ROLL.NO : AA.SC.U3BCA2207092
-->

<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <title>JSP Declaration, Expression, and Script let Example</title>
</head>
<body>

    <%-- 1. Declare a string variable named 'username' --%>
    <%! String username = "pinki Kumari"; %>

    <%-- 2. Use an expression tag to display a greeting message incorporating the username --%>
    <h2>Welcome, <%= username %>!</h2>

    <%-- 3. Use another expression tag to print the length of the username string --%>
    <p>The length of your username is: <%= username.length() %></p>

    <%-- 4. Use a scriptlet tag to check if the first character of username is an uppercase letter --%>
    <%
        char firstChar = username.charAt(0);
        boolean isUpperCase = Character.isUpperCase(firstChar);
    %>

    <%-- 5. Display a message indicating whether the first character is uppercase or not --%>
    <p>
        The first character '<%= firstChar %>' is 
        <%= (isUpperCase ? "an uppercase letter ✅" : "not an uppercase letter ❌") %>.
    </p>

</body>
</html>
