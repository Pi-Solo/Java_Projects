/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package survey;

/**
 *
 * @author hp
 */
 
 //Name: Pinki Kumari
// Roll Number: AA.SC.U3BCA2207092

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class SurveyServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve form data
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String age = request.getParameter("age");
        String job = request.getParameter("job");
        String feedback = request.getParameter("feedback");

        // Set data as request attributes
        request.setAttribute("name", name);
        request.setAttribute("email", email);
        request.setAttribute("age", age);
        request.setAttribute("job", job);
        request.setAttribute("feedback", feedback);

        // Forward the request to ResultServlet
        RequestDispatcher dispatcher = request.getRequestDispatcher("resultServlet");
        dispatcher.forward(request, response);
    }
}
