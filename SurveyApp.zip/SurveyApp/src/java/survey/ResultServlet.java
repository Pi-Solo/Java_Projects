/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package survey;

/**
 *
 * @author hp
 */

//Name: Pinki Kumari
//Roll Number: AA.SC.U3BCA2207092

package com.example;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;

public class ResultServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve attributes from the forwarded request
        String name = (String) request.getAttribute("name");
        String email = (String) request.getAttribute("email");
        String age = (String) request.getAttribute("age");
        String job = (String) request.getAttribute("job");
        String feedback = (String) request.getAttribute("feedback");

        // Set response content type
        response.setContentType("text/html");

        // Generate response
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head><title>Survey Result</title></head>");
        out.println("<body>");
        out.println("<h2>Thank You, " + name + "!</h2>");
        out.println("<p>We have received your feedback.</p>");
        out.println("<p><strong>Details Submitted:</strong></p>");
        out.println("<ul>");
        out.println("<li><strong>Email:</strong> " + email + "</li>");
        out.println("<li><strong>Age:</strong> " + age + "</li>");
        out.println("<li><strong>Job:</strong> " + job + "</li>");
        out.println("<li><strong>Feedback:</strong> " + feedback + "</li>");
        out.println("</ul>");
        out.println("</body>");
        out.println("</html>");
    }
}
