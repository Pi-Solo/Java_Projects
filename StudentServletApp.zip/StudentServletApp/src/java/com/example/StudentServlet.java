
// Name: Pinki Kumari
// Roll Number: AA.SC.U3BCA2207092

package com.example;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;

public class StudentServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Set response content type
        response.setContentType("text/html");

        // Collect data from form
        String name = request.getParameter("name");
        String roll = request.getParameter("roll");
        String course = request.getParameter("course");

        // Generate response
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head><title>Student Details</title></head>");
        out.println("<body>");
        out.println("<h2>Welcome, " + name + "!</h2>");
        out.println("<p>Here are your details:</p>");
        out.println("<ul>");
        out.println("<li><strong>Name:</strong> " + name + "</li>");
        out.println("<li><strong>Roll Number:</strong> " + roll + "</li>");
        out.println("<li><strong>Course:</strong> " + course + "</li>");
        out.println("</ul>");
        out.println("</body>");
        out.println("</html>");
    }
}
