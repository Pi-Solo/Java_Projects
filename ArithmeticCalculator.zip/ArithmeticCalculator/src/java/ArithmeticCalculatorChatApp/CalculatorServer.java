/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ArithmeticCalculatorChatApp;

/**
 *
 * @author hp
 */
// CalculatorServer.java
// Name: Pinki Kumari
// Roll Number: AA.SC.U3BCA2207092

import java.io.*;
import java.net.*;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;

public class CalculatorServer {
    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(12346)) {
            System.out.println("Calculator Server is running...");
            Socket socket = serverSocket.accept();
            System.out.println("Client connected!");

            BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);

            ScriptEngine engine = new ScriptEngineManager().getEngineByName("JavaScript");
            String expression;

            while (true) {
                expression = input.readLine();
                if (expression.equalsIgnoreCase("stop")) {
                    System.out.println("Client disconnected.");
                    break;
                }

                try {
                    Object result = engine.eval(expression);
                    output.println("Result: " + result);
                } catch (Exception e) {
                    output.println("Error: Invalid Expression");
                }
            }

            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

