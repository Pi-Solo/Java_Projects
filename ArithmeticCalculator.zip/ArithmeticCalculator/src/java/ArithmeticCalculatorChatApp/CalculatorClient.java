/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ArithmeticCalculatorChatApp;

/**
 *
 * @author hp
 */
// CalculatorClient.java
// Name: Pinki Kumari
// Roll Number: AA.SC.U3BCA2207092

import java.io.*;
import java.net.*;

public class CalculatorClient {
    public static void main(String[] args) {
        try (Socket socket = new Socket("localhost", 12346)) {
            System.out.println("Connected to the Calculator Server!");

            BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);

            BufferedReader consoleInput = new BufferedReader(new InputStreamReader(System.in));
            String expression, result;

            while (true) {
                System.out.print("Enter expression ( e.g, '1+1' or 'stop' to exit): ");
                expression = consoleInput.readLine();
                output.println(expression);
                if (expression.equalsIgnoreCase("stop")) {
                    System.out.println("Client disconnected.");
                    break;
                }

                result = input.readLine();
                System.out.println(result);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

