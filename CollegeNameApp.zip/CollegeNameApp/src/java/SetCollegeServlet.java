
//Name: Pinki Kumari
//Roll Number: AA.SC.U3BCA2207092

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletContext;

@WebServlet("/SetCollegeServlet")
public class SetCollegeServlet extends HttpServlet {

    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String collegeName = request.getParameter("Amrita Vishwa Vidyapeetham");
        ServletContext context = getServletContext();
        context.setAttribute("Amrita Vishwa Vidyapeetham", collegeName); // Store in application scope
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<h3>College Name '" + collegeName + "' has been stored.</h3>");
        out.println("<a href='GetCollegeServlet'>Click here to see stored College Name</a>");
    }
}
