
//Name: Pinki Kumari
//Roll Number: AA.SC.U3BCA2207092

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletContext;

@WebServlet("/GetCollegeServlet")
public class GetCollegeServlet extends HttpServlet {

    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        ServletContext context = getServletContext();
        String collegeName = (String) context.getAttribute("Amrita Vishwa Vidyapeetham"); // Retrieve from application scope
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        if (collegeName != null) {
            out.println("<h2>Stored College Name: " + collegeName + "</h2>");
        } else {
            out.println("<h2>No College Name Found</h2>");
        }
    }
}
