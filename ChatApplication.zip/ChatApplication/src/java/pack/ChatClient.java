/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pack;

/**
 *
 * @author hp
 */

// Name: Pinki Kumari
// Roll Number: AA.SC.U3BCA2207092

import java.io.*;
import java.net.*;

public class ChatClient {
    public static void main(String[] args) {
        try (Socket socket = new Socket("localhost", 12345)) {
            System.out.println("Connected to the server!");

            BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);

            BufferedReader consoleInput = new BufferedReader(new InputStreamReader(System.in));
            String clientMessage, serverMessage;

            while (true) {
                System.out.print("Client: ");
                clientMessage = consoleInput.readLine();
                output.println(clientMessage);
                if (clientMessage.equalsIgnoreCase("stop")) {
                    System.out.println("Client stopped the chat.");
                    break;
                }

                serverMessage = input.readLine();
                System.out.println("Server: " + serverMessage);
                if (serverMessage.equalsIgnoreCase("stop")) {
                    System.out.println("Server disconnected.");
                    break;
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

